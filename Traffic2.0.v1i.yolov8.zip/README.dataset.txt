# Traffic2.0 > 2024-09-03 12:02pm
https://universe.roboflow.com/alomgir/traffic2.0

Provided by a Roboflow user
License: MIT

